import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
import cv2
import numpy as np
from cv_bridge import CvBridge

class TurtleBot3ColorFollower(Node):
    def __init__(self):
        super().__init__('turtlebot3_color_follower')

        # Publishers and subscribers
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.image_sub = self.create_subscription(Image, '/camera/image_raw', self.image_callback, 10)

        # Movement command
        self.twist = Twist()

        # Image processing
        self.bridge = CvBridge()

        # Robot behavior state
        self.following_green = False
        self.avoiding_red = False

        self.get_logger().info("TurtleBot3 Color Follower Node Initialized")

    def image_callback(self, msg):
        """Process the camera image to detect green and red objects."""
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

            # Process image to detect colors
            self.detect_colors(cv_image)
        except Exception as e:
            self.get_logger().error(f"Image processing error: {e}")

    def detect_colors(self, frame):
        """Detect green and red objects in the image."""
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Define color ranges
        green_lower = np.array([40, 40, 40])  # Adjust these values for your simulation
        green_upper = np.array([80, 255, 255])
        red_lower1 = np.array([0, 70, 50])
        red_upper1 = np.array([10, 255, 255])
        red_lower2 = np.array([170, 70, 50])
        red_upper2 = np.array([180, 255, 255])

        # Create masks for green and red
        green_mask = cv2.inRange(hsv, green_lower, green_upper)
        red_mask1 = cv2.inRange(hsv, red_lower1, red_upper1)
        red_mask2 = cv2.inRange(hsv, red_lower2, red_upper2)
        red_mask = cv2.bitwise_or(red_mask1, red_mask2)

        # Moments for object detection
        green_moment = cv2.moments(green_mask)
        red_moment = cv2.moments(red_mask)

        if red_moment['m00'] > 0:
            # Red object detected: avoid it
            self.avoiding_red = True
            self.following_green = False
            self.avoid_object(red_moment)
        elif green_moment['m00'] > 0:
            # Green object detected: follow it
            self.following_green = True
            self.avoiding_red = False
            self.follow_object(green_moment)
        else:
            # No objects detected: stop or move randomly
            self.avoiding_red = False
            self.following_green = False
            self.search_for_object()

    def avoid_object(self, moment):
        """Run away from the detected red object."""
        cx = int(moment['m10'] / moment['m00'])  # Center of the red object
        self.get_logger().warn(f"Running away from red object at x={cx}")

        # Turn away based on object position
        if cx < 320:  # Object is on the left
            self.twist.angular.z = -0.5
        else:  # Object is on the right
            self.twist.angular.z = 0.5

        # Move backward
        self.twist.linear.x = -0.2
        self.cmd_vel_pub.publish(self.twist)

    def follow_object(self, moment):
        """Follow the detected green object."""
        cx = int(moment['m10'] / moment['m00'])  # Center of the green object
        self.get_logger().info(f"Following green object at x={cx}")

        # Adjust direction based on object's position
        if cx < 320:  # Object is on the left
            self.twist.angular.z = 0.3
        elif cx > 320:  # Object is on the right
            self.twist.angular.z = -0.3
        else:
            self.twist.angular.z = 0.0

        # Move forward
        self.twist.linear.x = 0.2
        self.cmd_vel_pub.publish(self.twist)

    def search_for_object(self):
        """Move randomly when no objects are detected."""
        self.get_logger().info("Searching for green objects...")
        self.twist.linear.x = 0.1
        self.twist.angular.z = 0.2
        self.cmd_vel_pub.publish(self.twist)

    def stop_movement(self):
        """Stop the robot."""
        self.twist.linear.x = 0.0
        self.twist.angular.z = 0.0
        self.cmd_vel_pub.publish(self.twist)

def main(args=None):
    rclpy.init(args=args)
    color_follower = TurtleBot3ColorFollower()

    try:
        rclpy.spin(color_follower)
    except KeyboardInterrupt:
        color_follower.get_logger().info("Shutting down Color Follower Node")
        color_follower.stop_movement()
    finally:
        color_follower.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
